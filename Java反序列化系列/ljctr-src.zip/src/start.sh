#!/bin/bash

java -jar /opt/app/DemoApplication.jar